"use strict";

let fruits = ["Orange", "Watermelon", "Banana", "Kiwi", "Lemon", "Peach",];
fruits.sort();

// 2. Задание

/* function FindingFruit(nameFruit, array) {
   return array.indexOf(nameFruit);
}

console.log(FindingFruit("Peach", fruits)); */