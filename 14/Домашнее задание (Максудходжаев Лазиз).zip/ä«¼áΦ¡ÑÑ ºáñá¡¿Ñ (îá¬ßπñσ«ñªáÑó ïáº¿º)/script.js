"use strict";

// 1. Задание. https://stackoverflow.com/questions/70724526/how-to-create-a-function-that-omits-key-value-pairs-from-an-object-and-creates

// let car1 = {
//    model: "Kia",
//    speed: 70,
//    color: "Black",
// };

/* function Without(obj, keys) {
   let res = {};

   for (let key in obj) {
      if (keys.includes(key)) continue;

      res[key] = obj[key];
   }

   return res;
}

let car2 = Without(car1, ['speed', 'model']);

console.log(car2); */


// 2. Задание

/* function IsEpmty(obj) {

   for (let key in obj) {
      return true;
   }

   return false
}

console.log(IsEpmty(car1)); */


// 3. Задание

/* let car2 = car1;
let car3 = {};
let car4 = {};

function IsEqual(obj1, obj2) {

   if (obj1 === obj2) {
      return true;
   }

   return false;
}

console.log(IsEqual(car1, car2));
console.log(IsEqual(car3, car4)); */


// 4. Задание

/*let car1 = {
   model: {
      name: undefined,
   },
};

let car2 = {
   model: {
      name: 'Kia',
   },
   color: null,
}

function IsEmptyDeep(obj) {

   for (let key in obj) {
      if (typeof obj[key] === 'object') {
         let obj2 = obj[key];

         for (let key2 in obj2) {
            if (obj2[key2] === undefined) {
               return true;
            }
            return false;
         }
      }
   }
}

console.log(IsEmptyDeep(car1)) // true
console.log(IsEmptyDeep(car2)) // false */


// 5. Задание

/* let car1 = {
   model: {
      name: 'Ford',
   },
};

let car2 = {
   speed: 70,
   color: "Black",
   model: {
      name: 'Kia',
   },
}

function IsEqualDeep(obj1, obj2) {
   let res1 = {};
   let res2 = {};

   for (let key1 in obj1) {
      if (typeof obj1[key1] === 'object') {
         res1 = obj1[key1];

         for (let key2 in res1) {
            res1 = res1[key2];
         }
      }
   }

   for (let key3 in obj2) {
      if (typeof obj2[key3] === 'object') {
         res2 = obj2[key3];


         for (let key4 in res2) {
            res2 = res2[key4];
         }
      }
   }

   if (res1 === res2) return true;
   return false;
}

console.log(IsEqualDeep(car1, car2)); */


// 6. Задание.

/* let car1 = {
   model: "Kia",
   speed: 70,
};

let car2 = {
   speed: 70,
   color: "Black",
};

function Intersection(obj1, obj2) {

   for (let key1 in obj1) {
      for (let key2 in obj2) {

         if (obj1[key1] === obj2[key2]) return obj1[key1];
      }
   }

   return 'Нету поверхностных пересечений';
}

console.log(Intersection(car1, car2)); */


// 7. Задание. Напишите функцию, которая глубоко находит пересечения объектов и возвращает объект пересечений.

/* let car1 = {
   name: {
      best: 'Yes',
   },
   model: "Kia",
   speed: 70,
   color: "Black",
};

let car2 = {
   model: "Kia",
   speed: 70,
   name: {
      best: 'Yes',
   },
   color: "Black",
};

function IntersectionDeep(obj1, obj2) {
   let res1 = {};
   let res2 = {};

   for (let key1 in obj1) {
      for (let key2 in obj2) {

         if (typeof obj1[key1] === 'object' && typeof obj2[key2] === 'object') {
            res1 = obj1[key1];
            res2 = obj2[key2];

            for (let key1 in res1) {
               for (let key2 in res2) {

                  if (res1[key1] === res2[key2]) return res1[key1];
               }
            }
         }
      }
   }

   return 'Нету глубоких пересечений';
}

console.log(IntersectionDeep(car1, car2)); */